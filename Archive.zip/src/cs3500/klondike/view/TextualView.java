package cs3500.klondike.view;

import java.io.IOException;

/**
 * interface for the TetualView.
 */
public interface TextualView {
  void render() throws IOException;
}
